<?php
/* Copyright (C) Xvezda <http://xvezda.com> */

/**
 * @class  sitemapAdminModel
 * @author Xvezda (xvezda@naver.com)
 * @brief  Sitemap module admin model class.
 */

class sitemapAdminModel extends sitemap
{
	/**
	 * Initialization
	 * @return void
	 */
	function init()
	{
	}
}

/* End of file sitemap.admin.model.php */
/* Location: ./modules/sitemap/sitemap.admin.model.php */