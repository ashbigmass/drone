xe-module-maps
==============

xe-widget-maps 와 연계되어서 지도 정보를 저장, 관리하는 모듈.
