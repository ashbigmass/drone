# Board-DX-for-XE

[XpressEngine(XE)](http://www.xpressengine.com/) 에서 사용하는 게시판 모듈

* 버전
 * 2.8

* 라이센스
 * [GNU GPL](http://www.gnu.org/licenses/gpl.html)

* 설명
 * XE 게시판 모듈입니다.
 * 기본 게시판 보다 좀더 많은 기능을 제공합니다.

* 지원하는 버전
 * xe 1.8

* 설치 폴더
 * ./modules/beluxe/

* 주의 사항
 * 업데이트 전 관리 페이지를 열어두시고 진행하시길 권고합니다.
 * 업데이트 후 관리 페이지 우측 하단 [캐시파일 재생성] 해주세요.

* [게시판 DX 도움말](https://github.com/phiDelbak/Board-DX-for-XE/wiki)
