# WooriAlim
## 경로 : /xe/modules/ggmailing/
XE(XpressEngine) Module