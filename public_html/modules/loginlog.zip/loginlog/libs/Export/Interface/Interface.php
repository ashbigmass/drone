<?php
interface Export_Interface
{
	public function export();
}