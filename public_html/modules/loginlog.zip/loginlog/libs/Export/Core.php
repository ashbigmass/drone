<?php
class Export_Core implements Export_Interface
{
	public function export()
	{
	}
}