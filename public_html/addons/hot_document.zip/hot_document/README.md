# hot_document
XE addon for Popular Documents extraction.
